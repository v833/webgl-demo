const str:string='Hello World'
console.log(str);
